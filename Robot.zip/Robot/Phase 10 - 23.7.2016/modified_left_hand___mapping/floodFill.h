#include <Arduino.h>

#define NORTH 0
#define EAST 1
#define SOUTH 2
#define WEST 3

const int neighboringCells[4][2] = {
  { -1, 0},
  {0, 1},
  {1, 0},
  {0, -1}
};

const byte neighboringWalls[4][2] = {
  {0, 0},
  {0, 1},
  {1, 0},
  {0, 0}
};

template <byte ROWS, byte COLUMNS>
class floodFill
{
  private:
    // vertical walls array
    boolean verticalWalls[ROWS][COLUMNS + 1];

    // horizontal walls array
    boolean horizontalWalls[ROWS + 1][COLUMNS];

  public:
    // value array
    byte values[ROWS][COLUMNS];

    byte mouseRow;
    byte mouseColumn;
    byte mouseHeading;

    byte targetRow;
    byte targetColumn;

    //Constructor method (called when the maze is created)
    floodFill()
    {
      //initialize verticalWalls (add exterior walls)
      for (byte i = 0; i < ROWS; i++)
      {
        for (byte j = 0; j < COLUMNS + 1; j++)
        {
          if (j == 0 || j == COLUMNS)
          {
            verticalWalls[i][j] = true;
          }
        }
      }

      //initialize horizontalWalls (add exterior walls)
      for (byte i = 0; i < ROWS + 1; i++)
      {
        for (byte j = 0; j < COLUMNS; j++)
        {
          if (i == 0 || i == ROWS)
          {
            horizontalWalls[i][j] = true;
          }
        }
      }
    }

    //Add your code here
    void solve() {
      //initialize array
      for (byte i = 0; i < ROWS; i++) {
        for (byte j = 0; j < COLUMNS; j++) {
          values[i][j] = 255;
        }
      }
      // set target cell
      values[targetRow][targetColumn] = 0;

      bool continueSolving = true;
      while (continueSolving)
      {
        continueSolving = false;
        for (byte i = 0; i < ROWS; i++)
        {
          for (byte j = 0; j < COLUMNS; j++)
          {
            if (values[i][j] < 255)
            {
              for (byte k = 0; k < 4; k++)
              {
                int neighboringCellRow = i + neighboringCells[k][0];
                int neighboringCellColumn = j + neighboringCells[k][1];

                byte neighboringWallRow = i + neighboringWalls[k][0];
                byte neighboringWallColumn = j + neighboringWalls[k][1];

                bool wallExists = false;

                if (k == NORTH || k == SOUTH)
                  wallExists = horizontalWalls[neighboringWallRow][neighboringWallColumn];
                else
                  wallExists = verticalWalls[neighboringWallRow][neighboringWallColumn];

                if (values [neighboringCellRow][neighboringCellColumn] == 255 && !wallExists)
                {
                  values [neighboringCellRow][neighboringCellColumn] = values[i][j] + 1;
                  continueSolving = true;
                }
              }
            }
          }
        }
      }
    }

    byte findBestNeighbor()
    {
      byte turnDifference=5;
      byte valueBestNeighbor=255;
      byte desiredHeading=NORTH;
      
      for (byte k = 0; k < 4; k++)
      {
        int neighboringCellRow = mouseRow + neighboringCells[k][0];
        int neighboringCellColumn = mouseColumn + neighboringCells[k][1];

        byte neighboringWallRow = mouseRow + neighboringWalls[k][0];
        byte neighboringWallColumn = mouseColumn + neighboringWalls[k][1];

        bool wallExists = false;

        if (k == NORTH || k == SOUTH)
          wallExists = horizontalWalls[neighboringWallRow][neighboringWallColumn];
        else
          wallExists = verticalWalls[neighboringWallRow][neighboringWallColumn];

        if (values [neighboringCellRow][neighboringCellColumn] < valueBestNeighbor && !wallExists)
        {
          valueBestNeighbor = values [neighboringCellRow][neighboringCellColumn];
          desiredHeading = k;
//          turnDifference=abs(desiredHeading-mouseHeading);
//          if (turnDifference==3)
//          turnDifference=1;
        }
//        if (values [neighboringCellRow][neighboringCellColumn] = valueBestNeighbor && !wallExists)
//        {
//          byte difference=abs(mouseHeading-k);
//          if (difference==3)
//          difference=1;
//          if (difference<turnDifference)
//          {
//            valueBestNeighbor = values [neighboringCellRow][neighboringCellColumn];
//            desiredHeading = k;
//          }
//        }
      }
      return desiredHeading;
    }

    void addWalls(byte cardinalDirection)
    {
      switch(cardinalDirection)
      {
        case NORTH:
          horizontalWalls[mouseRow][mouseColumn]=true;
          break;
        case EAST:
          verticalWalls[mouseRow][mouseColumn+1]=true;
          break;
        case SOUTH:
          horizontalWalls[mouseRow+1][mouseColumn]=true;
          break;
        case WEST:
          verticalWalls[mouseRow][mouseColumn]=true;
          break;
      }
    }

    void addVirtualWalls()
    {
      horizontalWalls[2][4] = true;
      verticalWalls[2][4] = true;
      verticalWalls[1][3] = true;
    }

    /*Do not change or add code below this line

      floodFill Print Function Version 2
      This version of the print function has been modified to print
      any size maze (the previous version could not print large
      mazes) and to work with the btMonitor Android App I wrote,
      which is available through my free online course at:
      http://udemy.com/nanomouse
      Scroll down to "Wireless Debugging with the Bluetooth Module"
      and go to the Downloadable Materials section of the lecture.*/

    void print()
    {
      for (byte i = 0; i < 2 * ROWS + 1; i++)
      {
        for (byte j = 0; j < 2 * COLUMNS + 1; j++)
        {
          //Add Horizontal Walls
          if (i % 2 == 0 && j % 2 == 1)
          {
            if (horizontalWalls[i / 2][j / 2] == true)
            {
              Serial3.print(" ---");
            }
            else
            {
              Serial3.print("    ");
            }
          }

          //Add Vertical Walls
          if (i % 2 == 1 && j % 2 == 0)
          {
            if (verticalWalls[i / 2][j / 2] == true)
            {
              Serial3.print("|");
            }
            else
            {
              Serial3.print(" ");
            }
          }

          //Add Flood Fill Values
          if (i % 2 == 1 && j % 2 == 1)
          {
            if ((i - 1) / 2 == mouseRow && (j - 1) / 2 == mouseColumn)
            {
              if (mouseHeading == NORTH)
              {
                Serial3.print(" ^ ");
              }
              else if (mouseHeading == EAST)
              {
                Serial3.print(" > ");
              }
              else if (mouseHeading == SOUTH)
              {
                Serial3.print(" v ");
              }
              else if (mouseHeading == WEST)
              {
                Serial3.print(" < ");
              }
            }
            else
            {
              byte value = values[(i - 1) / 2][(j - 1) / 2];
              if (value >= 100)
              {
                Serial3.print(value);
              }
              else
              {
                Serial3.print(" ");
                Serial3.print(value);
              }
              if (value < 10)
              {
                Serial3.print(" ");
              }
            }
          }
        }
        Serial3.print("\n");
      }
      Serial3.print("\n");
    }
};
